Reality2D is global mod for CS2D!
That adds realism and team play!
Mod by Rostik
Official site: https://github.com/Rostik1205/Reality2D/upload/main

Have fun!